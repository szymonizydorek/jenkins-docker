package displaywidth

//go:generate go run -C internal/gen .
