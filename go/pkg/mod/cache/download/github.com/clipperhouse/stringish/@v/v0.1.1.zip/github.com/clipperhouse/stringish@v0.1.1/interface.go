package stringish

type Interface interface {
	~[]byte | ~string
}
