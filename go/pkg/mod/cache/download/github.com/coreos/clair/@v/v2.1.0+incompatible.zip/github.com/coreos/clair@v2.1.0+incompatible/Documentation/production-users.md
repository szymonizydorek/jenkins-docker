# Production users

This document tracks people and use cases for Clair in production. [Join the community](https://github.com/coreos/Clair/), and help us keep the list up-to-date.

## [Quay.io](https://quay.io/)

Quay is CoreOS' enterprise-ready container registry. It displays the results of a Clair security scan on each hosted image's page.

